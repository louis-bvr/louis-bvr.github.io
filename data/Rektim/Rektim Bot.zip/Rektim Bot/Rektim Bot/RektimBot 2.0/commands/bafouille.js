exports.run = (client, msg, args) => {
    msg.channel.send("C'est votre ultime bafouille Gui ?");
}
