exports.run = (client, msg, args) => {
    msg.channel.send({files:['https://user-images.githubusercontent.com/40717116/59713388-a8764a00-920f-11e9-9371-443cf800f003.gif']});
}
