exports.run = (client, msg, args) => {
    msg.channel.send("BONJOUR! Je suis le pésident à ZORANA! \nSi je suis là, c'est pour vous présenter mon eau. Parce que mon eau elle est SPÉCIAL! ELLE A DES BUBULLES !!", {files:['https://mediagamaniak.cdn.re/vidcap/palmashow-parodie-pub.mp4.jpg']});
}
