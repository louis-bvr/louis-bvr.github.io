exports.run = (client, msg, args) => {
    for (var boucle = 0; boucle < 5; boucle++)
    msg.channel.send("@everyone TATAAAAAAAA YOYOOOOO :microphone: :musical_score: :microphone: :musical_score: ");
}
