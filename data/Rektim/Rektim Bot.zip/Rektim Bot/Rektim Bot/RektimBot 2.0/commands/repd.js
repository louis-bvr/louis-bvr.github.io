exports.run = (client, msg, args) => {
    msg.channel.send("D, la réponse D");
}
