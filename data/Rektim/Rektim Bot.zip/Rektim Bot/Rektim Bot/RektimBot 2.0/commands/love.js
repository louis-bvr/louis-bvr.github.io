exports.run = (client, msg, args) => {
    msg.channel.send("WHAT IS LOVE !? Tel est la question ! https://www.youtube.com/watch?v=dAIpjgvhKsA");
}
